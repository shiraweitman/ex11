import java.io.*;
import java.util.ArrayList;
import java.util.regex.*;


class JackTokenizer {
    public  String currentToken;
    private final ArrayList<String> symbols = new ArrayList<>();
    public BufferedReader bufferedReader;
    private File xmlFile;
    File cleaned;
    char pointer;
    private boolean tempPointer;
    private boolean intFlag;
    public TOKEN_TYPE currentTokenType;


    JackTokenizer (File inputFile) throws FileNotFoundException {
        this.tempPointer = false;
        try {
            cleaned = new File(inputFile.getAbsolutePath().
                    replaceAll(".jack", ".txt"));
            FileWriter fileWriter = new FileWriter(cleaned);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            this.cleanFile(bufferedWriter, new BufferedReader(new FileReader(inputFile)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileReader fileReader = new FileReader(cleaned);
        this.bufferedReader = new BufferedReader(fileReader);

        initialSymbols();
    }

    enum TOKEN_TYPE {KEYWORD, SYMBOL, IDENTIFIER, INT_CONST, STRING_CONST}

    enum KEYWORD {CLASS, METHOD, FUNCTION, CONSTRUCTOR, INT, BOOLEAN, CHAR,
        VOID, VAR, STATIC, FIELD, LET, DO, IF, ELSE, WHILE, RETURN,
        TRUE, FALSE, NULL, THIS}

     private void cleanFile(BufferedWriter bufferedWriter, BufferedReader bufferedReader) throws IOException {
        String line;
        while ((line = bufferedReader.readLine()) != null){
            if(!line.startsWith("//") && !line.contains("/**") && !line.contains(" *") && !line.equals("") && !line.equals("\t")){
                line = line.replaceAll("\t", "");
                line = line.replaceAll("  ", "");
                String[] splitedLine = line.split("//");
                bufferedWriter.write(splitedLine[0]);
            }
        }

        bufferedWriter.close();
        bufferedReader.close();
     }

    private void initialSymbols(){
        symbols.add("{");
        symbols.add("}");
        symbols.add("(");
        symbols.add(")");
        symbols.add("[");
        symbols.add("]");
        symbols.add(".");
        symbols.add(",");
        symbols.add(";");
        symbols.add("+");
        symbols.add("-");
        symbols.add("*");
        symbols.add("/");
        symbols.add("&");
        symbols.add("|");
        symbols.add("<");
        symbols.add(">");
        symbols.add("=");
        symbols.add("~");
    }

//    void readFile() throws IOException {
//        // write init
//        this.bufferedWriter.write("<tokens>");
//        this.bufferedWriter.newLine();
//        // while has more tokens
//
//        this.bufferedWriter.write("</tokens>");
//        this.bufferedWriter.close();
//
//    }


    boolean hasMoreTokens() throws IOException {
        int currentChar;
        currentChar =  this.bufferedReader.read();
        if(currentChar == -1){
            return false;
        } else {
            this.pointer = (char) currentChar;
            return true;
        }
    }

    void advance() throws IOException {
        // System.out.println(this.currentToken);
        this.currentToken = "";
        if(this.tempPointer){
            this.currentTokenType = tokenType();
            this.tempPointer = false;
            return;
        }
        if(this.intFlag){
            this.currentTokenType = tokenType();
            this.intFlag = false;
            return;
        }
        if (hasMoreTokens()){
            while (this.pointer==' '){
                this.pointer = (char) this.bufferedReader.read();
            }
            this.currentTokenType = tokenType();
        }
    }

    TOKEN_TYPE tokenType() throws IOException {
        // handle symbol token
        if(symbols.contains(String.valueOf(this.pointer))){
            String specialSymb = specialSymbol(this.pointer);
            this.currentToken = (!specialSymb.equals("0")) ? specialSymb : String.valueOf(this.pointer);
            //writeToken("symbol", (!specialSymb.equals("0")) ? specialSymb : String.valueOf(this.pointer));
            this.pointer = 0;
            return TOKEN_TYPE.SYMBOL;

        // handle int case
        } else if (String.valueOf(this.pointer).matches("-?\\d+(\\.\\d+)?")){
            this.currentToken = String.valueOf(this.pointer);
            char nextChar = (char) this.bufferedReader.read();
            // while we have more integers, concat to one integer
            while (String.valueOf(nextChar).matches("-?\\d+(\\.\\d+)?")){
                this.currentToken = this.currentToken + nextChar;
                nextChar = (char) this.bufferedReader.read();
            }
            this.pointer = nextChar;
            this.intFlag = true;
            //writeToken("integerConstant", String.valueOf(this.pointer));
            return TOKEN_TYPE.INT_CONST;

        // handle string case
        } else if(String.valueOf(this.pointer).equals("\"")){
            // while we have more string's chars, concat to one string
            char nextChar = (char) this.bufferedReader.read();
            while (!String.valueOf(nextChar).equals("\"")){
                this.currentToken = this.currentToken+nextChar;
                nextChar = (char) this.bufferedReader.read();
            }
            //writeToken("stringConstant", this.currentToken);
            return TOKEN_TYPE.STRING_CONST;

        // decide if it is a identifier or keyword
        } else {
            this.currentToken = String.valueOf(this.pointer);
            char nextChar = (char) this.bufferedReader.read();
            // while isn't a a symbol or space, continue
            while ((!symbols.contains(String.valueOf(nextChar))) && (!String.valueOf(nextChar).equals(" "))){
                this.currentToken = this.currentToken + nextChar;
                nextChar = (char) this.bufferedReader.read();
            }
            // save the final char to a var, maybe it's a symbol
            this.pointer = nextChar;
            if(this.symbols.contains(String.valueOf(this.pointer))){
                this.tempPointer = true;
            }
            // clean the line
            this.currentToken = this.currentToken.replaceAll("[\r\n]+", "");

            // get the keyword val (if it's identifier return null)
            KEYWORD keyword = keyWord();
            if(keyword != null){
                // writeToken("keyword", this.currentToken);
                return TOKEN_TYPE.KEYWORD;
            }
            // it is an identifier :-)
            if(!this.currentToken.equals(" ") && !this.currentToken.equals(".*(?:[ \r\n\t].*)+")) {
                this.currentToken = this.currentToken.replaceAll(" ", "");
                //writeToken("identifier", this.currentToken);
                //this.pointer = nextChar;
                return TOKEN_TYPE.IDENTIFIER;
            }
            return null;
        }

    }

    private String specialSymbol(char pointer) {
        switch (pointer){
            case '<':
                return "&lt;";
            case '>':
                return "&gt;";
            case '\"':
                return "&quot;";
            case '&':
                return "&amp;";
            default: return "0";
        }
    }



    KEYWORD keyWord(){
        switch (this.currentToken){
            case "class": return KEYWORD.CLASS;
            case "method": return KEYWORD.METHOD;
            case "function": return KEYWORD.FUNCTION;
            case "constructor": return KEYWORD.CONSTRUCTOR;
            case "int": return KEYWORD.INT;
            case "boolean": return KEYWORD.BOOLEAN;
            case "char": return KEYWORD.CHAR;
            case "void": return KEYWORD.VOID;
            case "var": return KEYWORD.VAR;
            case "static": return KEYWORD.STATIC;
            case "field": return KEYWORD.FIELD;
            case "let": return KEYWORD.LET;
            case "do": return KEYWORD.DO;
            case "if": return KEYWORD.IF;
            case "else": return KEYWORD.ELSE;
            case "while": return KEYWORD.WHILE;
            case "return": return KEYWORD.RETURN;
            case "true": return KEYWORD.TRUE;
            case "false": return KEYWORD.FALSE;
            case "null": return KEYWORD.NULL;
            case "this": return KEYWORD.THIS;
        }
        return null;
    }

    TOKEN_TYPE symbol(){
        if(symbols.contains(String.valueOf(this.pointer))) {
            return TOKEN_TYPE.SYMBOL;
        }
        return null;
    }

    String identifier(){
        return null;
    }

    int intVal(){
        return 0;
    }

    String stringVal(){
        return null;
    }

}
