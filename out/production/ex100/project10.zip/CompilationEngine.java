
import javax.management.BadAttributeValueExpException;
import java.io.*;
import java.util.ArrayList;


class CompilationEngine {
    private BufferedWriter bufferedWriter;
    private JackTokenizer tokenizer;
    private ArrayList<String> operations = new ArrayList<>();


    CompilationEngine(File inputFile, File outputFile) throws IOException {
        this.tokenizer = new JackTokenizer(inputFile);
        FileWriter fileWriter = new FileWriter(outputFile);
        this.bufferedWriter = new BufferedWriter(fileWriter);
        initialSymbols();
    }

    private void writeToken(String tokenType, String token) throws IOException {
        //System.out.println(token.toCharArray());
        //System.out.println(tokenType.toCharArray());
        bufferedWriter.write("<");
        bufferedWriter.write(tokenType);
        bufferedWriter.write("> ");
        bufferedWriter.write(token);
        bufferedWriter.write(" </");
        bufferedWriter.write(tokenType);
        bufferedWriter.write(">");
        bufferedWriter.newLine();
        if(token.equals("[")){
            //System.out.println("");
        }
    }

    private void writeLine(String line) throws IOException {
        this.bufferedWriter.write(line);
        this.bufferedWriter.newLine();
        //System.out.println(line);
    }

    void CompileClass() throws IOException {
        writeLine("<class>");
        tokenizer.advance();
        writeToken("keyword", tokenizer.currentToken); // write "class"
        tokenizer.advance();
        writeToken("identifier", tokenizer.currentToken); // write the class name
        tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write {
        tokenizer.advance();
        while (tokenizer.currentToken.equals("static") || tokenizer.currentToken.equals("field")){
            CompileClassVarDec();
            // System.out.println(tokenizer.currentToken);
        }
        while (!tokenizer.currentToken.equals("}")){
            //System.out.println("test: " + tokenizer.currentToken);
            compileSubroutineDec();
        }
        writeToken("symbol", tokenizer.currentToken); // write }
        writeLine("</class>");
        tokenizer.bufferedReader.close();
//        tokenizer.cleaned.delete();
        this.bufferedWriter.close();
    }

    void CompileClassVarDec() throws IOException {
        writeLine("<classVarDec>");
        varDecHelper();
        writeLine("</classVarDec>");
    }

    void CompileSubroutine(){}

    void compileParameterList() throws IOException {
        // todo: call this method only if the current token isn't ")"!
        writeLine("<parameterList>");
        if(!tokenizer.currentToken.equals(")")){ // not empty
            checkType(); // write the var type
            tokenizer.advance();
            writeToken("identifier", tokenizer.currentToken); // write the var name
            tokenizer.advance();
            while (true){
                if(tokenizer.currentToken.equals(",")){
                    writeToken("symbol", tokenizer.currentToken); // write ","
                    tokenizer.advance(); //advance to the expression after the comma
                    checkType(); // write the var type
                    tokenizer.advance();
                    writeToken("identifier", tokenizer.currentToken); // write the var name
                    tokenizer.advance();
                } else {
                    break;
                }
            }
        }

//        while (!tokenizer.currentToken.equals(")")){
//            checkType();
//            tokenizer.advance();
//            writeToken("identifier", tokenizer.currentToken);
//            tokenizer.advance();
//            if(tokenizer.currentToken.equals(",")){
//                writeToken("symbol", tokenizer.currentToken);
//                tokenizer.advance();
//            }
//        }
//        //tokenizer.advance();

        writeLine("</parameterList>");
    }

    void compileVarDec() throws IOException {
        writeLine("<varDec>");
        varDecHelper();
        writeLine("</varDec>");
    }

    private void varDecHelper() throws IOException {
        writeToken("keyword", tokenizer.currentToken); // write var/static/field
        tokenizer.advance();
        checkType(); // write the var type
        tokenizer.advance();
        writeToken("identifier", tokenizer.currentToken); // the var name
        tokenizer.advance();
        checkMoreVars();
        writeToken("symbol", tokenizer.currentToken); // write ;
        tokenizer.advance();
    }

    private void checkType() throws IOException {
        if (tokenizer.currentToken.equals("int") || tokenizer.currentToken.equals("char") ||
                tokenizer.currentToken.equals("boolean")){
            this.writeToken("keyword", tokenizer.currentToken);
        } else {
            this.writeToken("identifier", tokenizer.currentToken);
        }
    }

    private void checkMoreVars() throws IOException {
        while (!tokenizer.currentToken.equals(";")){
            if(tokenizer.currentToken.equals(",")){
                writeToken("symbol", tokenizer.currentToken);
            } else {
                writeToken("identifier", tokenizer.currentToken);
            }
            tokenizer.advance();
        }
    }

    void compileStatements() throws IOException {
        writeLine("<statements>");
        mainLoop: while (!tokenizer.currentToken.equals("}")) {
            switch (tokenizer.currentToken) {
                case "do":
                    compileDo();
                    break;
                case "let":
                    compileLet();
                    break;
                case "if":
                    compileIf();
                    break;
                case "while":
                    compileWhile();
                    break;
                case "return":
                    compileReturn();
                    break;
                default:
                    //System.out.println("maybe there is problem with mainloop");
                    break mainLoop;
            }
        }
        writeLine("</statements>");

    }

    void compileDo() throws IOException {
        writeLine("<doStatement>");
        writeToken("keyword", tokenizer.currentToken); // write "do"
        tokenizer.advance();
        // todo : I wrote here the identifier because I want to "save" the method from it (Maayan)
        writeToken("identifier", tokenizer.currentToken); // write the first identifier of subroutineCall
        tokenizer.advance();
        compileSubroutineCall();
        writeToken("symbol", tokenizer.currentToken); // write: ;
        tokenizer.advance();
        writeLine("</doStatement>");
    }

    void compileLet() throws IOException {
        writeLine("<letStatement>");
        writeToken("keyword", tokenizer.currentToken); // write "let"
        tokenizer.advance();
        writeToken("identifier", tokenizer.currentToken); // the var name
        tokenizer.advance();
        if (!tokenizer.currentToken.equals("=")){
            writeToken("symbol", tokenizer.currentToken); // write: "["
            tokenizer.advance();
            CompileExpression();
            // todo : tokenizer.advance(); ????
            writeToken("symbol", tokenizer.currentToken); // write: "]"
            tokenizer.advance();
        }
        writeToken("symbol", tokenizer.currentToken); // write: =
        tokenizer.advance();
        CompileExpression();
        // todo : tokenizer.advance(); Maayan ????
        writeToken("symbol", tokenizer.currentToken); // write: ;
        tokenizer.advance();
        writeLine("</letStatement>");

    }

    //TODO: this func actually equals to compileIf - need to merge them together (I make part of this)
    void compileWhile() throws IOException {
        writeLine("<whileStatement>");
        compileWhileIf();
        //tokenizer.advance(); todo: we delete
        writeLine("</whileStatement>");

    }

    void compileReturn() throws IOException {
        writeLine("<returnStatement>");
        writeToken("keyword", tokenizer.currentToken); // write return
        tokenizer.advance();
        if (!tokenizer.currentToken.equals(";")) { // there is an expression before ";"
            CompileExpression();
            // todo : tokenizer.advance(); ????
        }
        writeToken("symbol", tokenizer.currentToken); // write: ;
        tokenizer.advance();
        writeLine("</returnStatement>");
    }

    void compileIf() throws IOException {
        writeLine("<ifStatement>");
        compileWhileIf();
        if(tokenizer.currentToken.equals("else")){
            compileElse();
        }
        writeLine("</ifStatement>");
    }

    private void compileWhileIf() throws IOException {
        writeToken("keyword", tokenizer.currentToken); // write if/while
        tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write (
        tokenizer.advance();
        CompileExpression();
        // todo : tokenizer.advance(); ????
        writeToken("symbol", tokenizer.currentToken); // write )
        tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write {
        tokenizer.advance();
        compileStatements();
        //tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write }
        tokenizer.advance();
    }

    private void compileElse() throws IOException {
        writeToken("keyword", tokenizer.currentToken); // write else
        tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write {
        tokenizer.advance();
        compileStatements();
        //tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write }
        tokenizer.advance();
    }

    private void initialSymbols(){
        operations.add("-");
        operations.add("+");
        operations.add("*");
        operations.add("/");
        operations.add("&amp;");
        operations.add("|");
        operations.add("&lt;");
        operations.add("&gt;");
        operations.add("=");
    }
    
    void CompileExpression() throws IOException {
        writeLine("<expression>");
        // writeToken("identifier", tokenizer.currentToken);
        while(true){
            if(tokenizer.currentToken.equals(";")){
                break;
            }
            if(tokenizer.currentToken.equals(")")){
                //tokenizer.advance(); // todo centerrrrrrr??????
                break;
            }
            if(tokenizer.currentToken.equals(",")){
                break;
            }
            JackTokenizer.TOKEN_TYPE firstTokenType = tokenizer.currentTokenType;
            String firstToken = tokenizer.currentToken;
            tokenizer.advance();
            CompileTerm(firstToken, firstTokenType);
            if (operations.contains(tokenizer.currentToken)){
                writeToken("symbol", tokenizer.currentToken); // write operation
                tokenizer.advance(); // todo: is it really needed?
                JackTokenizer.TOKEN_TYPE nextTokenType = tokenizer.currentTokenType;
                String nextToken = tokenizer.currentToken;
                tokenizer.advance();

                CompileTerm(nextToken, nextTokenType);
            } else {
                // TODO- notice: we actually made the advance op!!!
                break;
            }
        }
        writeLine("</expression>");
    }

    void CompileTerm(String firstToken, JackTokenizer.TOKEN_TYPE firstTokenType) throws IOException {
        writeLine("<term>");
        switch (firstTokenType){
            case INT_CONST:
                writeToken("integerConstant", firstToken);
                break;
            case STRING_CONST:
                writeToken("stringConstant", firstToken);
                break;
            case KEYWORD:
                writeToken("keyword", firstToken);
                break;
            case IDENTIFIER:
                writeToken("identifier", firstToken); // varName
                if(tokenizer.currentToken.equals("[")){
                    writeToken("symbol", tokenizer.currentToken); // write "["
                    tokenizer.advance();
                    CompileExpression();
                    //TODO ??? tokenizer.advance(); ???
                    writeToken("symbol", tokenizer.currentToken);  // write "]"
                    tokenizer.advance(); // todo: make problems?~?~?
                } else if (tokenizer.currentToken.equals("(") || tokenizer.currentToken.equals(".") ) {
                    compileSubroutineCall();
                }
                else if(tokenizer.currentToken.equals(")")){
                    //writeToken("identifier", firstToken);
                    break;
                } else if(tokenizer.currentToken.equals(",")){
                    break; // todo expression inside expression list
                }
                break;

            case SYMBOL:
                if(firstToken.equals("(")) { // check if "("
                    writeToken("symbol", firstToken); // write "("
                    CompileExpression();
                    //TODO ??? tokenizer.advance(); ???
                    writeToken("symbol", tokenizer.currentToken);  // write ")"
                    tokenizer.advance(); // todo - we add it now (20:11)
                } else if(firstToken.equals("~")) {// check if "~"
                    writeToken("symbol", firstToken); // write "~"
                    ///
                    JackTokenizer.TOKEN_TYPE tildaTokenType = tokenizer.currentTokenType;
                    String tildaNextToken = tokenizer.currentToken;
                    tokenizer.advance();
                    ///
                    CompileTerm(tildaNextToken, tildaTokenType); // recursive call

                } else if(firstToken.equals("-")) {// check if "-"
                    writeToken("symbol", firstToken); // write "-"
                    ///
                    JackTokenizer.TOKEN_TYPE tildaTokenType = tokenizer.currentTokenType;
                    String tildaNextToken = tokenizer.currentToken;
                    tokenizer.advance();
                    ///
                    CompileTerm(tildaNextToken, tildaTokenType); // recursive call
                }

        }
        writeLine("</term>");
    }

    void CompileExpressionList() throws IOException {
        writeLine("<expressionList>");
        if(!tokenizer.currentToken.equals(")")){ // not empty
            CompileExpression();
            while (true){
                if(tokenizer.currentToken.equals(",")){
                    writeToken("symbol", tokenizer.currentToken); // write ","
                    tokenizer.advance(); //advance to the expression after the comma
                    CompileExpression();
                } else {
                    break;
                }
            }
        }
        writeLine("</expressionList>");

    }

    private void compileSubroutineBody() throws IOException {
        writeLine("<subroutineBody>");
        writeToken("symbol", tokenizer.currentToken); // write "{"
        tokenizer.advance();

        while (tokenizer.currentToken.equals("var")){
            compileVarDec();
            //tokenizer.advance();
        }
        compileStatements();
        //tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write "}"
        tokenizer.advance();
        writeLine("</subroutineBody>");

    }

    private void compileSubroutineCall() throws IOException {
        // todo : change the function arguments! (Maayan: I just remove the first writeToken)
        //writeLine("<subroutineCall>");
//        writeToken("identifier", tokenizer.currentToken); // write subroutine name
//        tokenizer.advance();
        if(tokenizer.currentToken.equals("(")){
            //System.out.println("NOthingTst");
//            writeToken("symbol", tokenizer.currentToken); // write "("
//            // TODO shira 22:00 single do bug
//            tokenizer.advance();
//            CompileExpressionList();
//            writeToken("symbol", tokenizer.currentToken); // write ")"
        } else {
            writeToken("symbol", tokenizer.currentToken); // write "."
            tokenizer.advance();
            writeToken("identifier", tokenizer.currentToken); // write subroutineName
            tokenizer.advance();
        }
        writeToken("symbol", tokenizer.currentToken); // write "("
        tokenizer.advance();
        // TODO check if there is a problem here
        CompileExpressionList();
        writeToken("symbol", tokenizer.currentToken); // write ")"
        tokenizer.advance();
        //writeLine("</subroutineCall>");
    }

    private void compileSubroutineDec() throws IOException {
        writeLine("<subroutineDec>");
        writeToken("keyword", tokenizer.currentToken); // write constructor/function/method
        tokenizer.advance();
        if(tokenizer.currentToken.equals("void")){
            writeToken("keyword", tokenizer.currentToken); // write void
        } else {
            checkType();
        }
        tokenizer.advance();
        writeToken("identifier", tokenizer.currentToken); // write subroutineName
        tokenizer.advance();
        writeToken("symbol", tokenizer.currentToken); // write "("
        tokenizer.advance();
        //if(!tokenizer.currentToken.equals(")")){
        compileParameterList();
        //}
        writeToken("symbol", tokenizer.currentToken); // write ")"
        tokenizer.advance();
        compileSubroutineBody();

        writeLine("</subroutineDec>");

    }


    }
